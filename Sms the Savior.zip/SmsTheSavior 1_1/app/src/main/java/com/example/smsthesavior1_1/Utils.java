package com.example.smsthesavior1_1;

public class Utils {

    public static final String EMAIL =  "";
    public static final String PASSWORD =  "";

}
